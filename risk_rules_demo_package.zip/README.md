
# Sample Risk Monitoring Rules Package (Synthetic)

This package contains synthetic data and example rule cards designed to illustrate how a bank might detect various risk scenarios. The SQL rules provided here have been anonymized and translated into English pseudocode to avoid disclosure of proprietary logic. They are intended for educational purposes.

## Contents

| File | Description |
|---|---|
| `loans_to_prohibited_sectors.csv` | Synthetic dataset for detecting personal loans whose funds flow to prohibited sectors. |
| `collateral_depreciation.csv` | Synthetic dataset for detecting collateral whose latest appraisal has depreciated by more than 20%. |
| `consumer_loan_repay_mortgage.csv` | Synthetic dataset for detecting consumer loans used to repay mortgages. |
| `business_loan_volume_increase.csv` | Synthetic dataset for detecting surges in business operating cash flows. |
| `multiple_secondhand_loans.csv` | Synthetic dataset for detecting multiple second-hand housing loans paid to the same person. |
| `rule_cards_en.md` | Human-readable rule cards with objectives, pseudocode, and governance notes. |
| `*_chart.png` | Example visualisations illustrating flagged vs non-flagged observations for each rule. |

## Usage

1. Review `rule_cards_en.md` for descriptions and logic of each rule.
2. Use the synthetic CSV files to prototype monitoring processes without relying on sensitive data.
3. The charts (`*.png`) visualise the proportion of flagged records and can serve as templates for reporting.

**Disclaimer**: These datasets are entirely synthetic. No real customer or transaction data is included. Thresholds and conditions may need adjustment for real-world scenarios.

