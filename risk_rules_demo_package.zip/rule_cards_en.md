# Rule Cards for Sample Risk Monitoring Rules

## Rule 1: Loan Funds Flowing to Prohibited Sectors

**Objective**: Identify personal loans where a significant portion of the loan proceeds is transferred to counterparties in prohibited sectors (e.g., real estate, securities, funds, commodity trading, insurance) shortly after disbursement.

**Key Input Fields**:
- Loan ID, Loan Amount, Loan Date
- Counterparty Name
- Transaction Amount and Date

**Pseudocode**:
```
for each loan in personal_loans:
    # find transactions within 10 days after loan disbursement
    subsequent_txs = transactions[ (tx.loan_id == loan.id) and (0 < tx.date - loan.date <= 10) ]
    # sum amounts to counterparties with prohibited keywords in their names
    prohibited_sum = sum(tx.amount for tx in subsequent_txs if contains_prohibited_keyword(tx.counterparty_name))
    # flag loan if at least 50% of the loan amount flowed to prohibited sectors and total > 100k
    if prohibited_sum >= 0.5 * loan.amount and prohibited_sum >= 100000:
        flag loan
```

**Governance Notes**: Use a configurable list of prohibited keywords and time window. Document data sources, filters, and threshold values. Maintain audit logs for each detected case.

---

## Rule 2: Collateral Depreciation Exceeding 20%

**Objective**: Detect loans secured by collateral whose latest appraised value has fallen by 20% or more compared to the initial appraisal at loan origination.

**Key Input Fields**:
- Loan ID
- Initial Appraisal Value
- Latest Appraisal Value

**Pseudocode**:
```
for each collateral in collaterals:
    depreciation_pct = (initial_value - latest_value) / initial_value
    if depreciation_pct >= 0.20:
        flag collateral and associated loan
```

**Governance Notes**: Ensure appraisal dates are comparable and appraisal standards are consistent. Trigger re-valuation or additional collateral requirements for flagged loans.

---

## Rule 3: Consumer Loan Used to Repay Mortgage

**Objective**: Identify consumer loans whose proceeds appear to have been used to repay mortgage loans, contrary to loan purpose restrictions.

**Key Input Fields**:
- Consumer Loan ID
- Loan Amount
- Mortgage Account Identifier
- Repayment Amount

**Pseudocode**:
```
for each consumer_loan in consumer_loans:
    # find payments from consumer loan account to mortgage account
    repayments = payments[(payment.source_account == consumer_loan.account) and (payment.target_account in mortgage_accounts)]
    repay_ratio = sum(repayment.amount) / consumer_loan.amount
    if repay_ratio >= 0.50:
        flag consumer_loan
```

**Governance Notes**: Cross-check with mortgage account details to confirm linkage. Threshold ratio can be adjusted (e.g., 50%) based on policy.

---

## Rule 4: Business Loan Operating Cash Flow Surge

**Objective**: Flag business loans where the borrower’s operating cash flow in the half-year immediately preceding loan disbursement is at least twice the operating cash flow of the earlier half-year. A sharp rise may indicate unusual inflows.

**Key Input Fields**:
- Loan ID
- Borrower ID
- Cash Flow in Preceding 0–180 days
- Cash Flow in Preceding 180–360 days

**Pseudocode**:
```
for each business_loan in business_loans:
    sum_half_year = sum_cashflow(borrower, period=0_to_180_days_before_loan)
    sum_prev_half = sum_cashflow(borrower, period=180_to_360_days_before_loan)
    if sum_half_year / sum_prev_half >= 2:
        flag business_loan
```

**Governance Notes**: Adjust the time windows or ratio threshold as needed. Exclude transactions with memos indicating normal repayments (e.g., "loan", "salary") to focus on business revenue inflows.

---

## Rule 5: Multiple Second-Hand Housing Loans Paid to the Same Person

**Objective**: Detect cases where multiple second-hand housing loans are disbursed and the funds are paid to the same natural person, which may indicate collusive behavior or capital concentration.

**Key Input Fields**:
- Borrower Identifier
- Payee Identifier
- Number of Loans
- Total Loan Amount

**Pseudocode**:
```
grouped = loans.groupby(payee_identifier)
for payee, loans_list in grouped:
    if count(loans_list) > 1:
        flag payee and associated loans
```

**Governance Notes**: Verify whether the payee is a legitimate seller or intermediary. Follow up with enhanced due diligence when multiple loans flow to the same payee.

```