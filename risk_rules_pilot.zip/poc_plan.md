# 30‑Day Proof‑of‑Concept Plan

This roadmap outlines a simple four‑week schedule for deploying and evaluating the pilot rules in a test environment.  You can adapt the timelines and deliverables to suit your institution’s processes and resource availability.

## Week 1 – Field Mapping & Environment Setup

* **Identify source systems and data owners.**  Determine which systems hold the loan, transaction and collateral data required by the pilot rules.
* **Map fields.**  Use `mapping.csv` to map your internal fields to the standard names (e.g., `loan_id`, `transaction_amount`, etc.).  Create database views or queries to align your schema to the expected structure.
* **Provision a test environment.**  Create a read‑only copy of the necessary tables or extract a representative subset into a sandbox database.
* **Load synthetic data for dry run.**  Verify that the sample scripts run successfully against the provided synthetic datasets.

## Week 2 – Data Validation & Rule Tuning

* **Run the rules on a small historical slice.**  Select a time period (e.g., one month of recent lending activity) and execute the SQL scripts against the sandbox.
* **Review outputs.**  Examine the flagged loans or collateral items.  Validate that the results make sense and align with known cases or expectations.
* **Adjust thresholds.**  Tune the ratio thresholds and amount filters to manage false positives.  Document any changes.
* **Prepare audit logs.**  Ensure that `run_id`, `input_hash` and `created_at` fields are captured for each execution and stored for review.

## Week 3 – Pilot Execution & Case Review

* **Run the rules across a broader dataset** (e.g., all loans originated in the past six months).
* **Distribute alerts.**  Send flagged cases to the relevant risk/compliance officers for review.
* **Collect feedback.**  Capture reviewer comments on false positives, true positives and any patterns noticed.
* **Begin summarising metrics.**  Calculate precision (true positives / total alerts) and the distribution of ratios, amounts and depreciation levels.

## Week 4 – Assessment & Next Steps

* **Conduct a wrap‑up meeting.**  Review performance metrics, user feedback and implementation challenges.
* **Decide on production roll‑out or further enhancement.**  If the rules prove valuable, plan the next phase: expanding coverage, integrating with case management and building dashboards.
* **Document lessons learned.**  Record threshold settings, tuning decisions and any data quality or mapping issues encountered.

By the end of 30 days, you should have a clear picture of how the rules perform in your environment and whether they merit a full‑scale deployment.