# Rule Cards – Pilot Package

This file documents three pilot rules designed for rapid proof‑of‑concept evaluations.  Each rule is presented on its own page with six sections: **Objective**, **Risk & Regulatory Context**, **Data Inputs**, **Logic**, **Thresholds & Tuning**, and **Outputs**.

---

## Rule R01 – Loan Funds Flow to Prohibited Sectors

### Objective

Identify personal loans where a substantial portion of the disbursed funds is transferred, within ten days of loan origination, to counterparties associated with prohibited or high‑risk sectors (e.g., speculative investments, real estate speculation or unregulated commodities).

### Risk & Regulatory Context

Loan agreements typically restrict the borrower’s use of funds to approved purposes.  Transferring funds into high‑risk or prohibited industries may indicate misuse of proceeds, misrepresentation or money‑laundering.  U.S. regulators—including the OCC and FinCEN—expect lenders to monitor loan proceeds for signs of misuse and potential BSA/AML violations.

### Data Inputs

| Standard Field | Description |
| --- | --- |
| `loan_id` | Unique identifier for the loan. |
| `customer_id` | Unique identifier for the borrower. |
| `loan_origination_date` | Date when the loan was funded/disbursed. |
| `loan_amount` | Total amount of the loan. |
| `transaction_date` | Date of each funds transfer. |
| `transaction_amount` | Amount of each transfer. |
| `counterparty_name` | Name of the receiving counterparty. |

### Logic (Pseudocode & Example SQL)

**Pseudocode:**

1. For each loan, collect all outbound transactions occurring within `loan_origination_date` + 10 days.
2. Flag each transaction where `lower(counterparty_name)` contains a prohibited keyword (e.g., `securities`, `fund`, `real estate`, `property`, `insurance`, `futures`).
3. Sum the `transaction_amount` of flagged transactions for each loan.
4. Calculate the ratio `prohibited_sum / loan_amount`.
5. If the ratio ≥ 0.50 **and** `prohibited_sum` ≥ 100 000 (in local currency), flag the loan as suspicious.

**Sample ANSI‑SQL (simplified):**

```sql
-- Rule R01 – Loan Funds Flow to Prohibited Sectors
WITH tx AS (
    SELECT t.loan_id,
           t.customer_id,
           t.loan_origination_date,
           t.loan_amount,
           tr.transaction_amount,
           tr.counterparty_name
    FROM   loans t
    JOIN   transactions tr
           ON tr.loan_id = t.loan_id
    WHERE  tr.transaction_date BETWEEN t.loan_origination_date
                                     AND t.loan_origination_date + INTERVAL '10' DAY
      AND  (
              lower(tr.counterparty_name) LIKE '%securities%'
           OR lower(tr.counterparty_name) LIKE '%fund%'
           OR lower(tr.counterparty_name) LIKE '%real estate%'
           OR lower(tr.counterparty_name) LIKE '%property%'
           OR lower(tr.counterparty_name) LIKE '%insurance%'
           OR lower(tr.counterparty_name) LIKE '%futures%'
          )
)
SELECT loan_id,
       customer_id,
       SUM(transaction_amount) AS prohibited_sum,
       SUM(transaction_amount) / MAX(loan_amount) AS ratio,
       'R01' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, customer_id)) AS input_hash,
       current_timestamp AS created_at
FROM   tx
GROUP BY loan_id, customer_id
HAVING SUM(transaction_amount) >= 100000
   AND SUM(transaction_amount) / MAX(loan_amount) >= 0.50;
```

### Thresholds & Tuning

* **Time window:** 10 days after disbursement is a typical look‑back; adjust based on your loan product and risk appetite.
* **Prohibited keywords:** Start with the provided list; expand or refine using your internal policy and watch‑list.
* **Amount thresholds:** The sample uses ≥50 % of loan amount and an absolute floor of 100 000.  Adjust these to manage false positives and ensure you capture materially significant misuse.

### Outputs

The script produces one record per flagged loan, including:

* `loan_id` and `customer_id`
* `prohibited_sum` – total amount transferred to prohibited sectors
* `ratio` – share of loan amount used in prohibited transactions
* `rule_id`, `run_id`, `input_hash`, `created_at` – audit fields
* Banks should review the flagged loans to determine if misuse occurred and file any required regulatory reports.

---

## Rule R02 – Collateral Depreciation Greater than 20 %

### Objective

Identify loans secured by collateral whose current appraised value has fallen by more than 20 % relative to its original appraisal.  Such depreciation may erode the bank’s recovery potential in the event of default and may require additional collateral or early intervention.

### Risk & Regulatory Context

Collateral monitoring is a core element of credit risk management.  Regulators expect lenders to maintain accurate collateral valuations and to take appropriate action when collateral value declines materially.  Significant depreciation can lead to under‑secured exposures and losses.

### Data Inputs

| Standard Field | Description |
| --- | --- |
| `loan_id` | Unique identifier for the loan. |
| `collateral_id` | Unique identifier for each item of collateral securing the loan. |
| `initial_appraisal_value` | The value at origination or first appraisal. |
| `latest_appraisal_value` | The most recent appraised value. |
| `borrower_id` | Identifier for the borrower. |
| `collateral_type` | Type/category of collateral (e.g., real estate, vehicle). |

### Logic (Pseudocode & Example SQL)

**Pseudocode:**

1. For each collateral item securing a loan, compute `depreciation = (initial_appraisal_value – latest_appraisal_value) / initial_appraisal_value`.
2. If `depreciation` ≥ 0.20 (20 %), flag the loan/collateral record.

**Sample ANSI‑SQL (simplified):**

```sql
-- Rule R02 – Collateral Depreciation > 20 %
SELECT loan_id,
       collateral_id,
       initial_appraisal_value,
       latest_appraisal_value,
       (initial_appraisal_value - latest_appraisal_value) / initial_appraisal_value AS depreciation,
       'R02' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, collateral_id)) AS input_hash,
       current_timestamp AS created_at
FROM   collaterals
WHERE  initial_appraisal_value > 0
  AND  (initial_appraisal_value - latest_appraisal_value) / initial_appraisal_value >= 0.20;
```

### Thresholds & Tuning

* **Depreciation threshold:** 20 % is a common trigger; consider adjusting to reflect market volatility and your risk tolerance.
* **Appraisal frequency:** Ensure that `latest_appraisal_value` is updated regularly.  Stale appraisals will mask depreciation.

### Outputs

The rule returns one record per collateral item with depreciation ≥20 %, including audit fields.  Lenders should re‑evaluate collateral coverage and consider requiring additional collateral or other risk mitigants.

---

## Rule R03 – Business Loan Transaction Volume Spike

### Objective

Detect personal or small‑business loans where the borrower’s account turnover in the six months prior to loan disbursement is at least double that of the same borrower in the preceding six‑month period.  An unusual spike in pre‑loan activity may signal “window dressing” or attempts to inflate perceived business activity.

### Risk & Regulatory Context

Lenders use bank statement activity to assess a business’s operating cash flows.  Borrowers could artificially inflate transactions before applying for a loan.  Regulators and internal auditors expect institutions to identify and investigate such anomalies to prevent fraud and misrepresentation.

### Data Inputs

| Standard Field | Description |
| --- | --- |
| `loan_id` | Unique identifier for the loan. |
| `customer_id` | Unique identifier for the borrower. |
| `business_entity_name` | Name of the borrower’s business/operating entity. |
| `loan_origination_date` | Date of loan disbursement. |
| `transaction_date` | Date of each account transaction. |
| `transaction_amount` | Amount of each transaction (debits/credits).  Only inflows relevant to operating activity should be included. |

### Logic (Pseudocode & Example SQL)

**Pseudocode:**

1. For each loan, compute two sums:
   * `sum_last_6m` – total transaction amount in the 180 days prior to `loan_origination_date`.
   * `sum_prev_6m` – total transaction amount in the 180 days before that (i.e., 180–360 days before origination).
2. Calculate the ratio `ratio = sum_last_6m / sum_prev_6m` (handle division by zero appropriately).
3. If `ratio` ≥ 2.0 (i.e., the last six months are at least twice the volume of the previous six months), flag the loan.

**Sample ANSI‑SQL (simplified):**

```sql
-- Rule R03 – Business Loan Volume Spike
WITH agg AS (
    SELECT loan_id,
           customer_id,
           SUM(CASE WHEN transaction_date BETWEEN loan_origination_date - INTERVAL '180' DAY
                     AND     loan_origination_date THEN transaction_amount ELSE 0 END) AS sum_last_6m,
           SUM(CASE WHEN transaction_date BETWEEN loan_origination_date - INTERVAL '360' DAY
                     AND     loan_origination_date - INTERVAL '180' DAY THEN transaction_amount ELSE 0 END) AS sum_prev_6m
    FROM   business_transactions
    GROUP BY loan_id, customer_id
)
SELECT loan_id,
       customer_id,
       sum_last_6m,
       sum_prev_6m,
       CASE WHEN sum_prev_6m = 0 THEN NULL ELSE sum_last_6m / sum_prev_6m END AS ratio,
       'R03' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, customer_id)) AS input_hash,
       current_timestamp AS created_at
FROM   agg
WHERE  sum_prev_6m > 0
  AND  sum_last_6m / sum_prev_6m >= 2.0;
```

### Thresholds & Tuning

* **Look‑back windows:** 180‑day periods are a common choice.  Longer or shorter windows may be appropriate depending on business cycle and seasonality.
* **Spike ratio:** The example uses ≥2.0.  Institutions may lower or raise this threshold based on portfolio characteristics and acceptable false‑positive rates.

### Outputs

The query returns flagged loans with their pre‑loan transaction sums and ratio, plus audit fields.  Analysts should review the underlying transactions to determine whether the spike reflects genuine business growth or artificial “window dressing.”