-- Rule: R03 – Business Loan Transaction Volume Spike
-- Version: 1.0
-- Author: Rosie Zhang
-- Description: Detects loans where the account turnover in the six months prior to origination is at least twice that of the preceding six months, indicating possible window dressing or inflated activity.  Includes audit fields for compliance.

WITH agg AS (
    SELECT loan_id,
           customer_id,
           SUM(CASE WHEN transaction_date BETWEEN loan_origination_date - INTERVAL '180' DAY
                     AND     loan_origination_date THEN transaction_amount ELSE 0 END) AS sum_last_6m,
           SUM(CASE WHEN transaction_date BETWEEN loan_origination_date - INTERVAL '360' DAY
                     AND     loan_origination_date - INTERVAL '180' DAY THEN transaction_amount ELSE 0 END) AS sum_prev_6m
    FROM   business_transactions
    GROUP BY loan_id, customer_id
)
SELECT loan_id,
       customer_id,
       sum_last_6m,
       sum_prev_6m,
       CASE WHEN sum_prev_6m = 0 THEN NULL ELSE sum_last_6m / sum_prev_6m END AS ratio,
       'R03' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, customer_id)) AS input_hash,
       current_timestamp AS created_at
FROM   agg
WHERE  sum_prev_6m > 0
  AND  sum_last_6m / sum_prev_6m >= 2.0;