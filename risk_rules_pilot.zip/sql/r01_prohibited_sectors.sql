-- Rule: R01 – Loan Funds Flow to Prohibited Sectors
-- Version: 1.0
-- Author: Zhang Lixin
-- Description: Identifies loans where ≥50 % of the disbursed amount is transferred within 10 days to counterparties linked to prohibited sectors such as securities, funds, real estate or insurance.  Designed for community banks using ANSI SQL.

WITH tx AS (
    SELECT l.loan_id,
           l.customer_id,
           l.loan_origination_date,
           l.loan_amount,
           t.transaction_amount,
           t.counterparty_name
    FROM   loans l
    JOIN   transactions t
           ON t.loan_id = l.loan_id
    WHERE  t.transaction_date BETWEEN l.loan_origination_date
                                     AND l.loan_origination_date + INTERVAL '10' DAY
      AND  (
              lower(t.counterparty_name) LIKE '%securities%'
           OR lower(t.counterparty_name) LIKE '%fund%'
           OR lower(t.counterparty_name) LIKE '%real estate%'
           OR lower(t.counterparty_name) LIKE '%property%'
           OR lower(t.counterparty_name) LIKE '%insurance%'
           OR lower(t.counterparty_name) LIKE '%futures%'
          )
)
SELECT loan_id,
       customer_id,
       SUM(transaction_amount) AS prohibited_sum,
       SUM(transaction_amount) / MAX(loan_amount) AS ratio,
       'R01' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, customer_id)) AS input_hash,
       current_timestamp AS created_at
FROM   tx
GROUP BY loan_id, customer_id
HAVING SUM(transaction_amount) >= 100000
   AND SUM(transaction_amount) / MAX(loan_amount) >= 0.50;