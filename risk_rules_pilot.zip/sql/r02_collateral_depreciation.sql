-- Rule: R02 – Collateral Depreciation > 20 %
-- Version: 1.0
-- Author: Rosie Zhang
-- Description: Flags collateral items whose current appraised value has fallen by at least 20 % relative to the original appraisal value.  Supports audit fields for traceability.

SELECT loan_id,
       collateral_id,
       initial_appraisal_value,
       latest_appraisal_value,
       (initial_appraisal_value - latest_appraisal_value) / initial_appraisal_value AS depreciation,
       'R02' AS rule_id,
       uuid() AS run_id,
       md5(concat_ws(',', loan_id, collateral_id)) AS input_hash,
       current_timestamp AS created_at
FROM   collaterals
WHERE  initial_appraisal_value > 0
  AND  (initial_appraisal_value - latest_appraisal_value) / initial_appraisal_value >= 0.20;