# Pilot Risk Monitoring Rules Package

This package contains a small set of sample rules and synthetic data to help community banks and credit unions quickly evaluate the benefit of rules‑based monitoring.  The package focuses on three common risk scenarios seen in consumer and small‑business lending: misuse of loan proceeds, collateral value deterioration and unusual spikes in business account activity.  All data in this package are **synthetic** and do not relate to any real customers or accounts.

## Contents

| File/Folder | Description |
| --- | --- |
| **rule_cards_en.md** | Markdown file containing the rule cards for the three pilot rules.  Each card describes the objective, regulatory context, inputs, logic (pseudocode & sample ANSI‑SQL), thresholds and outputs. |
| **mapping.csv** | A simple field mapping template.  Use this to map your institution’s field names to the standard names referenced in the rule cards.  The template includes the required fields for each rule and space to record your local equivalents. |
| **data/** | Folder containing synthetic sample datasets for each rule.  These datasets illustrate the minimum data required to run the rules and include expected outputs. |
| **sql/** | Folder containing sample ANSI‑SQL scripts for each rule.  These scripts are for illustration only and are not meant for production use.  Each script includes header comments with version, author and audit fields (`rule_id`, `run_id`, `input_hash`, `created_at`). |
| **poc_plan.md** | A 30‑day proof‑of‑concept roadmap outlining how to deploy and evaluate the pilot rules. |

## Deployment Guidelines

1. **Run on a copy or test environment.**  These rules are designed to execute against a read‑only replica or data mart.  Do not run them directly against your production database.  A small set of tables or views is sufficient—see the mapping template for the required fields.

2. **Field mapping.**  Before running the scripts, map your internal field names to the standard names provided in `mapping.csv`.  You may need to create views to align your schema to the expected structure.

3. **Threshold tuning.**  The thresholds in the sample scripts (e.g., 50 % of loan amount, 20 % depreciation, ratio ≥ 2) are starting points.  Tune them based on your risk appetite and portfolio characteristics.

4. **Audit fields.**  Each SQL script returns additional fields to support auditability: `rule_id` identifies the rule, `run_id` is a unique execution identifier (e.g., UUID), `input_hash` can be a checksum of the input dataset and `created_at` records when the rule was executed.

5. **Separation of environments.**  Keep your development/test environment separate from production.  Evaluate the rules on a small subset of historical data before rolling them out more widely.

## 30‑Day PoC Roadmap

See `poc_plan.md` for a suggested four‑week pilot schedule.  It covers field mapping, data validation, rule tuning, weekly review of results and documentation of false positives and false negatives.

## Disclaimer

This package is provided for demonstration and educational purposes only.  It does not contain any confidential or proprietary data.  You are responsible for ensuring compliance with all applicable laws and regulations when implementing any monitoring solution.