# Loan Funds Flow to Prohibited Sectors

**Objective**: Identify loans where a significant portion of disbursed funds are transferred to industries or merchants that are prohibited or restricted by lending policy.

**Risk & Reg Context**: U.S. regulators (OCC, FDIC) require banks to ensure loan proceeds are used for permitted purposes; funds diverted to prohibited sectors (e.g., gambling, real estate speculation) may violate lending agreements and trigger fair-lending or BSA/AML concerns.

**Data Inputs**:
- std_loan_id, std_customer_id
- std_transaction_date
- std_merchant_category (e.g., NAICS or MCC codes)
- std_transaction_amount
- std_loan_amount

**Logic (pseudocode & SQL)**:
Pseudocode:
```
For each loan_id:
  Sum transaction_amounts where merchant_category in PROHIBITED_LIST during monitoring window (e.g., first 10 days after disbursement).
  If sum >= 0.5 * loan_amount: flag loan_id as suspicious.
```

ANSI-SQL Example:
```sql
-- version: v1.0  author: Rosie Zhang  
SELECT loan_id, SUM(transaction_amount) AS total_prohib, loan_amount,
       CASE WHEN SUM(transaction_amount) >= 0.5 * loan_amount THEN 1 ELSE 0 END AS is_suspicious,
       'RULE_PROHIBITED_USE' AS rule_id, :run_id AS run_id, MD5(CONCAT(loan_id)) AS input_hash, CURRENT_TIMESTAMP AS created_at
FROM transactions
WHERE merchant_category IN ('Real Estate','Gambling','Insurance','Stocks')
GROUP BY loan_id, loan_amount;
```


**Thresholds & Tuning**:
Default threshold is 50% of loan_amount. Adjust threshold or prohibited list based on risk appetite or regulatory guidance.

**Outputs**:
- is_suspicious: 1 if total prohibited transactions >= threshold, else 0
- Additional fields: rule_id, run_id, input_hash, created_at for audit.

# Collateral Depreciation > 20%

**Objective**: Detect collateralized loans where the market value of the collateral has fallen by more than 20% since origination.

**Risk & Reg Context**: Rapid depreciation of collateral undermines loan security and may breach loan-to-value (LTV) covenants; regulators expect timely re-assessment to avoid under-collateralization.

**Data Inputs**:
- std_loan_id
- std_collateral_id
- std_initial_value
- std_latest_value
- std_valuation_date

**Logic (pseudocode & SQL)**:
Pseudocode:
```
For each collateral_id:
  Compute depreciation = (initial_value - latest_value) / initial_value.
  If depreciation >= 0.20: flag as at-risk.
```

ANSI-SQL Example:
```sql
-- version: v1.0  author: Rosie Zhang
SELECT loan_id, collateral_id, initial_value, latest_value,
       (initial_value - latest_value)/initial_value AS depreciation_ratio,
       CASE WHEN (initial_value - latest_value)/initial_value >= 0.2 THEN 1 ELSE 0 END AS is_suspicious,
       'RULE_COLLATERAL_DEPR' AS rule_id, :run_id AS run_id, MD5(CONCAT(collateral_id)) AS input_hash, CURRENT_TIMESTAMP AS created_at
FROM collateral_valuations;
```


**Thresholds & Tuning**:
Default threshold is 20% decline; adjust if loan policy allows different haircut rates.

**Outputs**:
- is_suspicious: 1 if depreciation_ratio >= threshold
- Additional audit fields: rule_id, run_id, input_hash, created_at.

# Consumer Loan Used to Repay Mortgage

**Objective**: Identify consumer loans that are likely being used to repay mortgage loans, contrary to loan purpose.

**Risk & Reg Context**: Repayment of mortgage using consumer loans may mask refinancing activity and circumvent underwriting standards; regulators monitor this as misuse of consumer lending.

**Data Inputs**:
- std_loan_id
- std_consumer_loan_id
- std_mortgage_account_id
- std_payment_date
- std_payment_amount
- std_consumer_loan_amount

**Logic (pseudocode & SQL)**:
Pseudocode:
```
For each consumer_loan_id:
  Sum payments from consumer loan to mortgage accounts.
  If total payments >= 0.5 * consumer_loan_amount: flag as suspicious.
```

ANSI-SQL Example:
```sql
-- version: v1.0  author: Rosie Zhang
SELECT loan_id, consumer_loan_id, SUM(payment_amount) AS total_pay, consumer_loan_amount,
       CASE WHEN SUM(payment_amount) >= 0.5 * consumer_loan_amount THEN 1 ELSE 0 END AS is_suspicious,
       'RULE_CONSUMER_MORTG' AS rule_id, :run_id AS run_id, MD5(CONCAT(consumer_loan_id)) AS input_hash, CURRENT_TIMESTAMP AS created_at
FROM consumer_mortgage_payments
GROUP BY loan_id, consumer_loan_id, consumer_loan_amount;
```


**Thresholds & Tuning**:
Default threshold is 50% of consumer loan amount; adjust as per consumer lending policy.

**Outputs**:
- is_suspicious: 1 if total payments >= threshold
- Audit fields: rule_id, run_id, input_hash, created_at.

# Business Loan Monthly Volume Spike

**Objective**: Detect a sudden spike in monthly transaction volume for business loans relative to historical averages.

**Risk & Reg Context**: Unusual spikes may indicate misreporting, cash flow manipulation or fraud; OCC/Fed regulators expect monitoring for unusual patterns under BSA/AML and operational risk frameworks.

**Data Inputs**:
- std_loan_id
- std_month
- std_monthly_volume
- std_previous_average

**Logic (pseudocode & SQL)**:
Pseudocode:
```
For each loan_id:
  Compare monthly_volume for current month with previous_average.
  If monthly_volume >= 1.5 * previous_average: flag as suspicious.
```

ANSI-SQL Example:
```sql
-- version: v1.0  author: Rosie Zhang
SELECT loan_id, month, monthly_volume, previous_average,
       CASE WHEN monthly_volume >= 1.5 * previous_average THEN 1 ELSE 0 END AS is_suspicious,
       'RULE_BUS_VOL_SPIKE' AS rule_id, :run_id AS run_id, MD5(CONCAT(loan_id, month)) AS input_hash, CURRENT_TIMESTAMP AS created_at
FROM business_volume_summary;
```


**Thresholds & Tuning**:
Default threshold is 150% of previous average; adjust to tune sensitivity to seasonality.

**Outputs**:
- is_suspicious: 1 if monthly volume >= threshold
- Audit fields: rule_id, run_id, input_hash, created_at.

