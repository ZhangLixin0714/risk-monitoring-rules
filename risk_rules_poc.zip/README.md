# Risk Monitoring Rules Proof-of-Concept (PoC) Package

This package contains a starter set of monitoring rules, synthetic data, and templates to help community and regional banks quickly assess potential anomalies in loan usage, collateral valuation, and repayment patterns. The package is designed to be **lightweight**, **read-only**, and **auditable**.

## Contents

- **rule_cards_en.md** – Detailed specification of four rules (Loan funds flow to prohibited sectors, Collateral depreciation >20%, Consumer loan used to repay mortgage, Business loan monthly volume spike). Each rule card includes an Objective, Risk & Regulatory Context, Data Inputs, Logic (pseudocode & ANSI‑SQL), Thresholds & tuning guidance, and Outputs including audit fields.
- **mapping.csv** – A field mapping template. Map your core system's column names to the standard fields used in these rules.
- **Synthetic data CSV files** – Sample data sets for each rule (`prohibited_sector_transactions.csv`, `collateral_depreciation.csv`, `consumer_loan_mortgage_payments.csv`, `business_loan_volume_spike.csv`) with labels indicating expected flags. Use these to test your implementation and verify results.
- **SQL examples in the rule cards** – Include comments for version, author, run_id, and audit fields (rule_id, input_hash, created_at) to support traceability.

## Deployment Guidelines

1. **Read‑only implementation** – The provided SQL queries are designed to run on test or anonymized snapshots of your data warehouse. They do not modify data and assume only SELECT privileges on the necessary tables.
2. **Data mapping** – Complete the `mapping.csv` by mapping your actual table/column names to the standard fields (e.g., `std_loan_id` to your `loan_id`).
3. **Threshold tuning** – Default thresholds (e.g., 50% for prohibited sector spend, 20% for collateral depreciation) are suggested starting points. Adjust thresholds based on your risk appetite and portfolio characteristics.
4. **Audit fields** – The SQL examples output `rule_id`, `run_id`, `input_hash`, and `created_at`. Populate `run_id` with a unique identifier for each run. The `input_hash` can be computed from key fields to support traceability.
5. **Production separation** – Keep this PoC in a development or testing environment. Do not connect to production systems without appropriate change management and approvals.

## 30‑Day PoC Roadmap

| Week | Activities |
|-----|------------|
| **1. Field Mapping & Data Preparation** | – Assign a data analyst to map your fields to the standard template using `mapping.csv`.  
– Extract a small, anonymized sample (or test snapshot) for each rule. |
| **2. Sample Validation** | – Implement the ANSI‑SQL logic using your mapped fields.  
– Run queries on the sample data and compare outputs with the provided synthetic datasets.  
– Adjust mapping or queries as needed. |
| **3. Test Run & KPI Definition** | – Execute the rules in a test environment across a larger (historic) dataset.  
– Capture metrics such as number of flags, precision (true positives), false positives/negatives.  
– Define what constitutes a successful alert vs. noise. |
| **4. Review & Refinement** | – Conduct weekly reviews with risk/compliance stakeholders to evaluate alerts.  
– Adjust thresholds or logic based on feedback.  
– Document findings and decide on next steps (e.g., scale to more rules, production deployment). |

## Support

If you would like assistance tailoring these rules to your data or would like to participate in a longer pilot program, please contact **Rosie Zhang** (FRM, CIA) at rosiezhang1218@gmail.com. Feedback on this starter kit is welcome.
