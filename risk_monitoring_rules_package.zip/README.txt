This archive contains synthetic examples of risk monitoring rule templates.

Files included:
- model_index_concise.csv: A sample index of rules.
- Rule_Card_Template.md: A template for creating rule cards.

Note: The data and examples included in this package are entirely synthetic. They are intended solely for demonstration purposes and do not reflect any real customer data or confidential banking information.
